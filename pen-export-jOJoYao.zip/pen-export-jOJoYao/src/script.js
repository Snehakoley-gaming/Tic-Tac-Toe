let currentPlayer = 'X';
let board = ['', '', '', '', '', '', '', '', ''];
const winningCombos = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
];

const cells = document.querySelectorAll('.cell');
const playAgainButton = document.getElementById('play-again');
const resultDiv = document.getElementById('result');

cells.forEach(cell => cell.addEventListener('click', handleClick));
playAgainButton.addEventListener('click', resetGame);

function handleClick(e) {
    const index = parseInt(e.target.getAttribute('data-cell-index'));
    if (board[index] === '' && !checkWinner()) {
        board[index] = currentPlayer;
        e.target.textContent = currentPlayer;
        if (checkWinner()) {
            resultDiv.textContent = `Player ${currentPlayer} wins!`;
            playAgainButton.style.display = 'block';
        } else if (board.every(cell => cell !== '')) {
            resultDiv.textContent = "It's a draw!";
            playAgainButton.style.display = 'block';
        } else {
            currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
        }
    }
}

function checkWinner() {
    return winningCombos.some(combo => {
        return combo.every(index => {
            return board[index] === currentPlayer;
        });
    });
}

function resetGame() {
    board = ['', '', '', '', '', '', '', '', ''];
    currentPlayer = 'X';
    cells.forEach(cell => {
        cell.textContent = '';
    });
    resultDiv.textContent = '';
    playAgainButton.style.display = 'none';
}
